//
//  TableRowController.swift
//  dewWatch WatchKit Extension
//
// CPSC 599 iProgramming  - exdee watch group
// Alex Brylov
// Oscar Velez
// Kent Wong

import WatchKit

class TableRowController: NSObject {
    @IBOutlet var button: WKInterfaceButton!
    @IBOutlet var image: WKInterfaceImage!
}
